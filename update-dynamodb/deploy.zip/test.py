import boto3


s3 = boto3.resource('s3')
s3_object = s3.Object('youtubemp3mediafiles', 'dZ_Ab1XxxKg.mp3')
s3_object.metadata.update({'Content-Disposition':'attachment'})
s3_object.copy_from(CopySource={'Bucket':'youtubemp3mediafiles', 'Key':'dZ_Ab1XxxKg.mp3'}, Metadata=s3_object.metadata, MetadataDirective='REPLACE')